=== WP Doctor Clinic ===
Contributors: chatgpt
Tags: appointment, booking, clinic
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.0.0
License: GPLv2 or later
